//40223076 Fatemeh Moghiseh

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

//معرفی تابع
void solver(float a , float b , float c , float *x1 , float *x2);

//برنامه ی اصلی
int main() {
    float a,b,c;
    float t1=-1.0 , t2=-2.0;
    float *x1=&t1 , *x2=&t2;

    //دریافت ضرایب معادله
    printf("Please enter the coefficients of the standardized equation in order: ");
    scanf("%f%f%f" , &a , &b , &c);
    
    //فراخوانی تابع
    solver(a,b,c,x1,x2);

    //شروط برای پرینت ریشه تابع دارای دو ریشه یا ریشه مضاعف یا بدون ریشه
    if(*x1!=*x2 && *x1>=0 && *x2>=0) {
        printf("Number of roots=2\n");
        printf("The roots=%f , %f" , *x1 , *x2);
    }
    else if(*x1==*x2 && *x1>=0 && *x2>=0) {
        printf("Number of roots=1\n");
        printf("The root=%f" , *x1 );
    }
    else if(*x1<0 && *x2<0) {
         printf("This equation has no real root\n");
    }
return 0;
}


//تعریف تابع محاسبه گر ریشه
void solver(float a , float b , float c , float *x1 , float *x2) {

    float delta=(b*b)-(4.0*a*c);
    if(delta>0) {
        float rdelta=sqrt(delta);
        *x1=((-b)+rdelta)/(2.0*a);
        *x2=((-b)-rdelta)/(2.0*a);
    }
    else if(delta==0) {
        *x2=*x1=((-b)/(2.0*a));
    }
    else if(delta<0) {
        *x1=*x2=-1.0;
    }

}